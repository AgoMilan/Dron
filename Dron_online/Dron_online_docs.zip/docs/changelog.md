# 📜 Changelog – verze skriptů

### 🗓️ 2025-10-09 – Verze v2
- Oprava chyby TypeError při prázdných trackech
- Přidáno zobrazení FPS a počtu objektů
- Nastavena pevná velikost okna 640x480
- Stabilní běh s kamerou Vivotek RTSP

### 🗓️ 2025-10-08 – Verze v1
- První připojení kamery přes RTSP
- YOLOv8 + DeepSORT detekce a sledování
- Zobrazení ID a confidence
