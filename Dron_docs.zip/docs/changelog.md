# 📜 Changelog – verze projektu Dron

### 🗓️ 2025-10-09
- Přidána dokumentace `Dron_docs`
- Upraveny spouštěcí příkazy v `main.py`

### 🗓️ 2025-10-08
- První funkční verze YOLO trackeru
- Přidán OpenCV režim s MOSSE a CSRT
